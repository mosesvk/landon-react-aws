**To remove tags from a resource share**

The following ``untag-resource`` example removes the ``project`` tag key and associated value from the specified resource share. ::

    aws ram untag-resource \
        --tag-keys project

This command produces no output.